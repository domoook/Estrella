#-*-coding:utf-8-*-
name = input("What's your name ? >")
age = input("How old are you ? >")
print ("your name is %s, your age is %d" %(name, int(age)))
print ("你的名字是 %s, 你的年龄是 %d" %(name,int(age)))

