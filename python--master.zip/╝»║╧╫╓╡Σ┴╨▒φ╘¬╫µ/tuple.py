#-*-coding:utf-8-*-
nums = (0,1)
print("nums are", nums)
another = (0,1,[3,4])
print("nums are", another)
another[2][0] = 5
print("nums are", another);