#-*-coding:utf-8-*-
numset = set([1,3,5,7,9])
print(numset)
numset.add(4)
print(numset)
numset.add(4)
print(numset)
numset.remove(3)
print(numset)
numset2 = set([2,4,6,8,10])
print(numset&numset2)
print(numset|numset2)

